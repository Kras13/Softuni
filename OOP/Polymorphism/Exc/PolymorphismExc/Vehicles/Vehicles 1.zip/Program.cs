﻿using System;

namespace Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Vehicle car = CreateNewVehicle();
            Vehicle truck = CreateNewVehicle();

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                string[] line = Console.ReadLine().Split();

                string command = line[0];
                string type = line[1];
                double parameter = double.Parse(line[2]);

                try
                {
                    if (command == "Drive")
                    {
                        if (type == nameof(Car))
                        {
                            car.Drive(parameter);
                            Console.WriteLine($"Car travelled {parameter} km");
                        }
                        else if (type == nameof(Truck))
                        {
                            truck.Drive(parameter);
                            Console.WriteLine($"Truck travelled {parameter} km");
                        }
                    }
                    else if (command == "Refuel")
                    {
                        if (type == nameof(Car))
                        {
                            car.Refuel(parameter);
                        }
                        else if (type == nameof(Truck))
                        {
                            truck.Refuel(parameter);
                        }
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            //double carFuel = Math.Round(car.Fuel, 2);
            //double truckFuel = Math.Round(truck.Fuel, 2);

            Console.WriteLine($"Car: {car.Fuel:F2}");
            Console.WriteLine($"Truck: {truck.Fuel:F2}");
        }

        private static Vehicle CreateNewVehicle()
        {
            string[] input = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string type = input[0];

            if (type == nameof(Car))
            {
                double fuel = double.Parse(input[1]);
                double fuelConsumption = double.Parse(input[2]);

                return new Car(fuel, fuelConsumption);
            }
            else
            {
                double fuel = double.Parse(input[1]);
                double fuelConsumption = double.Parse(input[2]);

                return new Truck(fuel, fuelConsumption);
            }
        }
    }
}
