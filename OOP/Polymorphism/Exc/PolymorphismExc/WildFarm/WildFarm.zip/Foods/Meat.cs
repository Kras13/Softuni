﻿namespace WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(int qunatity) 
            : base(qunatity)
        {
        }
    }
}
