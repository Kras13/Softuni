﻿namespace WildFarm.Foods
{
    public class Fruit : Food
    {
        public Fruit(int qunatity) 
            : base(qunatity)
        {
        }
    }
}
